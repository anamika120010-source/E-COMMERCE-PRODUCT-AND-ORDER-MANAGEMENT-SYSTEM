
print("Welcome to E-COMMERCE PRODUCT & ORDER MANAGEMENT SYSTEM")
print()
user = input("What you would like to do? (Add product,View products,Search,Register,Place order,Cancle,View orders,Exit): ")

new_user = {}
product = {
        "ID":101,
        "Name":"Iphone",
        "category":"Electronic Device" ,
        "Price": 70_000,
        "Stock":20,
        "Status":"Available"
    }

 
if  user == "Add product" : 
 def add_product():
    
       Name = input("Enter product name: ")
       ID = int(input("enter product id:"))
       category = input("enter product category: ")
       price = int(input("enter product price: "))
       stock = int(input("enter no. of pieces available: "))
       status = input("enter available or not: ")
       product["Name"] = Name
       product["ID"] = ID
       product["category"] = category
       product["Price"] = price
       product["Stock"] = stock
       product["Status"] = status

 add_product()
print(product)   

if user == "View products":
    print(product)

if user == "Search":
    sch = input("how would you like to search by(id,name,category): ")
    if sch == "id":
        id = int(input("Enter the id:"))
        print(product["ID"])
        print(product["Name"])

    elif sch == "name":
        name = input("Enter product name")
        print(product["Name"])
    elif sch == "category":
        category = input("Enter product category: ")
        print(product["category"])

if user == "Register":
    def register():
        name = input("enter user name: ")
        id = int(input("enetr customer id:"))
        phone = int(input("enter phone number: "))
        email = input("enter email: ")
        new_user["name"] = name
        new_user["id"] = id
        new_user["phone"] = phone
        new_user["email"] = email


    register()
    print(register())

if user == "Place order":
        if user in new_user:
            user_id = int(input("enter your id"))
            product_id = int(input("enter product id"))
            quantity = int(input("enter quantity"))

            print("your order is palced.")


if user == "Exit":
      print("program stopped.")




 
     
#     

    
    
# system()